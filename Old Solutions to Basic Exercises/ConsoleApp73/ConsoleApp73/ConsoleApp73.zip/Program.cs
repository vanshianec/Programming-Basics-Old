﻿using System;



    public class Program
    {
        static void Main(string[] args)
        {
        Person p1 = new Person("Pesho",24);
        Console.WriteLine(p1.Age);
        Console.WriteLine(p1.Name);
        }
    }

